
def is_prime_v5(n):
    if n <= 1 or n % 2 == 0:
        return False
    for i in range(3, int(n**0.5) + 1, 2):
        if n % i == 0:
            return False
    return True

if __name__ == '__main__':
    x = int(input("Enter a number: "))
    if is_prime_v5(x):
        print(f"{x} is a prime number")
    else:
        print(f"{x} is NOT a prime number")